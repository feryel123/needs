/**
 * MongoDB database migrations using MongoBee.
 */
package com.mycompany.myapp.config.dbmigrations;
