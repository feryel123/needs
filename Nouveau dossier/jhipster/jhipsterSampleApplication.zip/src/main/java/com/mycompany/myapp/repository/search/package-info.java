/**
 * Spring Data Elasticsearch repositories.
 */
package com.mycompany.myapp.repository.search;
